import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, Alert, ActivityIndicator, Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { COLORS } from '../utils/theme';

export default function ProfileScreen({ navigation, route }) {
  const { userId } = route.params;
  const [profile, setProfile] = useState(null);
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => { loadProfile(); }, []);

  async function loadProfile() {
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).single();
    setProfile(data);
    setName(data?.full_name || '');
  }

  async function handleSave() {
    if (!name.trim()) return Alert.alert('Hata', 'İsim boş olamaz.');
    setLoading(true);
    try {
      await supabase.from('profiles').update({ full_name: name.trim() }).eq('id', userId);
      Alert.alert('✅', 'Profil güncellendi!');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  }

  async function handlePhotoChange() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return Alert.alert('İzin gerekli', 'Fotoğraf erişimi için izin ver.');

    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true, aspect: [1, 1] });
    if (result.canceled) return;

    setUploading(true);
    try {
      const uri = result.assets[0].uri;
      const fileName = `avatar_${userId}.jpg`;
      const formData = new FormData();
      formData.append('file', { uri, name: fileName, type: 'image/jpeg' });

      await supabase.storage.from('chat-images').upload(fileName, formData, { contentType: 'image/jpeg', upsert: true });
      const { data: urlData } = supabase.storage.from('chat-images').getPublicUrl(fileName);
      await supabase.from('profiles').update({ avatar_url: urlData.publicUrl }).eq('id', userId);
      await loadProfile();
      Alert.alert('✅', 'Profil fotoğrafı güncellendi!');
    } catch {
      Alert.alert('Hata', 'Fotoğraf yüklenemedi.');
    } finally {
      setUploading(false);
    }
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Profil</Text>
      </View>

      <View style={styles.content}>
        <TouchableOpacity style={styles.avatarWrap} onPress={handlePhotoChange}>
          {profile?.avatar_url ? (
            <Image source={{ uri: profile.avatar_url }} style={styles.avatarImg} />
          ) : (
            <Avatar name={profile?.full_name || ''} size={90} />
          )}
          <View style={styles.editBadge}>
            <Text style={styles.editBadgeText}>{uploading ? '⏳' : '📷'}</Text>
          </View>
        </TouchableOpacity>

        <Text style={styles.emailText}>{profile?.email}</Text>

        <View style={styles.fieldWrap}>
          <Text style={styles.label}>İSİM</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="Adın Soyadın"
            placeholderTextColor="#bbb"
          />
        </View>

        <TouchableOpacity style={styles.btn} onPress={handleSave} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Kaydet</Text>}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: { backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 12, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  content: { padding: 24, alignItems: 'center' },
  avatarWrap: { position: 'relative', marginBottom: 12 },
  avatarImg: { width: 90, height: 90, borderRadius: 45 },
  editBadge: { position: 'absolute', bottom: 0, right: 0, backgroundColor: COLORS.accent, borderRadius: 14, width: 28, height: 28, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
  editBadgeText: { fontSize: 12 },
  emailText: { fontSize: 14, color: '#888', marginBottom: 28 },
  fieldWrap: { width: '100%', marginBottom: 18 },
  label: { fontSize: 12, fontWeight: '700', color: '#555', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { borderWidth: 1.5, borderColor: '#E8E8E8', borderRadius: 12, padding: 13, fontSize: 15, color: '#222', backgroundColor: '#FAFAFA', width: '100%' },
  btn: { backgroundColor: COLORS.primary, borderRadius: 14, paddingVertical: 15, alignItems: 'center', width: '100%', elevation: 4 },
  btnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
