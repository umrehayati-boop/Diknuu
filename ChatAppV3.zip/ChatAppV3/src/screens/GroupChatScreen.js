import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, FlatList, TextInput, TouchableOpacity,
  StyleSheet, SafeAreaView, KeyboardAvoidingView, Platform,
  Image, Alert, Modal,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { COLORS, formatTime, formatDate } from '../utils/theme';

const EMOJIS = ['❤️', '😂', '😮', '😢', '👍', '🔥'];

export default function GroupChatScreen({ navigation, route }) {
  const { userId, groupId, groupName, senderName } = route.params;
  const [messages, setMessages] = useState([]);
  const [members, setMembers] = useState([]);
  const [text, setText] = useState('');
  const [uploading, setUploading] = useState(false);
  const [selectedMsg, setSelectedMsg] = useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const flatRef = useRef(null);

  useEffect(() => {
    loadMessages();
    loadMembers();

    const channel = supabase
      .channel(`group_${groupId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'group_messages', filter: `group_id=eq.${groupId}` },
        payload => {
          if (payload.new.sender_id !== userId) {
            setMessages(prev => [...prev, payload.new]);
            scrollToBottom();
          }
        })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'group_messages', filter: `group_id=eq.${groupId}` },
        payload => setMessages(prev => prev.map(m => m.id === payload.new.id ? payload.new : m)))
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  function scrollToBottom() {
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  }

  async function loadMessages() {
    const { data } = await supabase
      .from('group_messages')
      .select('*, sender:profiles!group_messages_sender_id_fkey(id,full_name)')
      .eq('group_id', groupId)
      .order('created_at', { ascending: true });
    setMessages(data || []);
    scrollToBottom();
  }

  async function loadMembers() {
    const { data } = await supabase
      .from('group_members')
      .select('user_id, profiles(id, full_name)')
      .eq('group_id', groupId);
    if (data) setMembers(data.map(d => d.profiles).filter(Boolean));
  }

  async function handleSend(imageUrl = null) {
    const content = text.trim();
    if (!content && !imageUrl) return;
    setText('');

    const { data, error } = await supabase.from('group_messages').insert({
      group_id: groupId, sender_id: userId,
      content: content || null, image_url: imageUrl || null,
    }).select().single();

    if (!error && data) {
      setMessages(prev => [...prev, data]);
      scrollToBottom();
    }
  }

  async function handleImagePick() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7 });
    if (result.canceled) return;

    setUploading(true);
    try {
      const uri = result.assets[0].uri;
      const fileName = `group_${userId}_${Date.now()}.jpg`;
      const formData = new FormData();
      formData.append('file', { uri, name: fileName, type: 'image/jpeg' });
      await supabase.storage.from('chat-images').upload(fileName, formData, { contentType: 'image/jpeg' });
      const { data: urlData } = supabase.storage.from('chat-images').getPublicUrl(fileName);
      await handleSend(urlData.publicUrl);
    } catch {
      Alert.alert('Hata', 'Fotoğraf gönderilemedi.');
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(msg) {
    Alert.alert('Mesajı Sil', 'Silmek istiyor musun?', [
      {
        text: 'Sil', style: 'destructive', onPress: async () => {
          await supabase.from('group_messages').update({ is_deleted: true, content: null, image_url: null }).eq('id', msg.id);
          setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, is_deleted: true, content: null, image_url: null } : m));
        }
      },
      { text: 'İptal' },
    ]);
    setSelectedMsg(null);
  }

  async function handleReaction(msg, emoji) {
    const reactions = msg.reactions || {};
    const users = reactions[emoji] || [];
    const hasReacted = users.includes(userId);
    const newUsers = hasReacted ? users.filter(u => u !== userId) : [...users, userId];
    const newReactions = { ...reactions, [emoji]: newUsers };
    if (newUsers.length === 0) delete newReactions[emoji];

    await supabase.from('group_messages').update({ reactions: newReactions }).eq('id', msg.id);
    setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, reactions: newReactions } : m));
    setShowEmojiPicker(false);
    setSelectedMsg(null);
  }

  function buildItems() {
    const items = [];
    let lastDate = null;
    messages.forEach(m => {
      const d = formatDate(m.created_at);
      if (d !== lastDate) { items.push({ type: 'date', id: 'date_' + m.id, label: d }); lastDate = d; }
      items.push({ type: 'msg', ...m });
    });
    return items;
  }

  function renderItem({ item }) {
    if (item.type === 'date') return <View style={styles.dateSep}><Text style={styles.dateLabel}>{item.label}</Text></View>;

    const isMe = item.sender_id === userId;
    const reactions = item.reactions || {};
    const hasReactions = Object.keys(reactions).length > 0;
    const senderName = item.sender?.full_name || 'Bilinmiyor';

    return (
      <TouchableOpacity activeOpacity={0.8} onLongPress={() => { setSelectedMsg(item); setShowEmojiPicker(false); }}
        style={[styles.bubbleWrap, isMe && styles.myWrap]}>
        {!isMe && <Text style={styles.senderName}>{senderName}</Text>}
        <View style={[styles.bubble, isMe ? styles.myBubble : styles.theirBubble]}>
          {item.is_deleted ? (
            <Text style={styles.deletedText}>🚫 Bu mesaj silindi</Text>
          ) : item.image_url ? (
            <Image source={{ uri: item.image_url }} style={styles.msgImage} resizeMode="cover" />
          ) : (
            <Text style={styles.msgText}>{item.content}</Text>
          )}
          <View style={styles.msgMeta}>
            <Text style={styles.msgTime}>{formatTime(item.created_at)}</Text>
          </View>
        </View>
        {hasReactions && (
          <View style={[styles.reactionsRow, isMe && styles.reactionsRowMe]}>
            {Object.entries(reactions).map(([emoji, users]) => (
              <TouchableOpacity key={emoji} style={styles.reactionBubble} onPress={() => handleReaction(item, emoji)}>
                <Text style={styles.reactionText}>{emoji} {users.length}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </TouchableOpacity>
    );
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <View style={styles.groupIcon}><Text style={styles.groupIconText}>👥</Text></View>
        <View style={styles.headerInfo}>
          <Text style={styles.headerName}>{groupName}</Text>
          <Text style={styles.headerSub}>{members.length} üye</Text>
        </View>
      </View>

      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          ref={flatRef}
          data={buildItems()}
          keyExtractor={item => item.id?.toString()}
          renderItem={renderItem}
          style={styles.messageList}
          contentContainerStyle={styles.messageContent}
          onContentSizeChange={scrollToBottom}
        />

        <View style={styles.inputBar}>
          <TouchableOpacity onPress={handleImagePick} style={styles.attachBtn}>
            <Text>{uploading ? '⏳' : '📷'}</Text>
          </TouchableOpacity>
          <View style={styles.inputWrap}>
            <TextInput
              style={styles.textInput}
              value={text}
              onChangeText={setText}
              placeholder="Mesaj yaz..."
              placeholderTextColor="#aaa"
              multiline
            />
          </View>
          <TouchableOpacity style={[styles.sendBtn, !text.trim() && styles.sendBtnInactive]} onPress={() => handleSend()}>
            <Text style={styles.sendIcon}>{text.trim() ? '➤' : '🎤'}</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      <Modal visible={!!selectedMsg && !showEmojiPicker} transparent animationType="fade" onRequestClose={() => setSelectedMsg(null)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setSelectedMsg(null)}>
          <View style={styles.actionMenu}>
            <TouchableOpacity style={styles.actionBtn} onPress={() => setShowEmojiPicker(true)}>
              <Text style={styles.actionText}>😊 Tepki Ekle</Text>
            </TouchableOpacity>
            {selectedMsg?.sender_id === userId && !selectedMsg?.is_deleted && (
              <TouchableOpacity style={styles.actionBtn} onPress={() => handleDelete(selectedMsg)}>
                <Text style={[styles.actionText, { color: COLORS.danger }]}>🗑️ Mesajı Sil</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity style={styles.actionBtn} onPress={() => setSelectedMsg(null)}>
              <Text style={styles.actionText}>İptal</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      <Modal visible={showEmojiPicker} transparent animationType="fade" onRequestClose={() => setShowEmojiPicker(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => { setShowEmojiPicker(false); setSelectedMsg(null); }}>
          <View style={styles.emojiPicker}>
            {EMOJIS.map(e => (
              <TouchableOpacity key={e} style={styles.emojiBtn} onPress={() => handleReaction(selectedMsg, e)}>
                <Text style={styles.emojiText}>{e}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  flex: { flex: 1 },
  header: { backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 8, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  groupIcon: { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  groupIconText: { fontSize: 20 },
  headerInfo: { flex: 1 },
  headerName: { color: '#fff', fontWeight: '700', fontSize: 16 },
  headerSub: { color: 'rgba(255,255,255,0.75)', fontSize: 12 },
  messageList: { flex: 1, backgroundColor: COLORS.chatBg },
  messageContent: { padding: 10 },
  dateSep: { alignItems: 'center', marginVertical: 10 },
  dateLabel: { backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 4, fontSize: 12, color: '#555', fontWeight: '600' },
  bubbleWrap: { marginBottom: 6, alignItems: 'flex-start' },
  myWrap: { alignItems: 'flex-end' },
  senderName: { fontSize: 11, color: COLORS.primaryLight, fontWeight: '700', marginBottom: 2, marginLeft: 4 },
  bubble: { maxWidth: '75%', padding: 9, paddingHorizontal: 12, borderRadius: 16, elevation: 1 },
  myBubble: { backgroundColor: COLORS.myBubble, borderBottomRightRadius: 4 },
  theirBubble: { backgroundColor: '#fff', borderBottomLeftRadius: 4 },
  msgText: { fontSize: 15, color: '#111', lineHeight: 20 },
  deletedText: { fontSize: 14, color: '#aaa', fontStyle: 'italic' },
  msgImage: { width: 200, height: 200, borderRadius: 10 },
  msgMeta: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 3 },
  msgTime: { fontSize: 11, color: '#888' },
  reactionsRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 3, gap: 4 },
  reactionsRowMe: { justifyContent: 'flex-end' },
  reactionBubble: { backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1, borderColor: '#eee', elevation: 1 },
  reactionText: { fontSize: 13 },
  inputBar: { backgroundColor: '#F0F0F0', flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 8, paddingVertical: 6, gap: 8 },
  attachBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', elevation: 1 },
  inputWrap: { flex: 1, backgroundColor: '#fff', borderRadius: 24, paddingHorizontal: 14, paddingVertical: 8, elevation: 1 },
  textInput: { fontSize: 15, color: '#222', maxHeight: 100 },
  sendBtn: { width: 46, height: 46, borderRadius: 23, backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center', elevation: 3 },
  sendBtnInactive: { backgroundColor: '#ccc', elevation: 0 },
  sendIcon: { fontSize: 18, color: '#fff' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  actionMenu: { backgroundColor: '#fff', borderRadius: 16, padding: 8, width: 220, elevation: 10 },
  actionBtn: { paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#F0F0F0' },
  actionText: { fontSize: 15, color: '#222', fontWeight: '500' },
  emojiPicker: { backgroundColor: '#fff', borderRadius: 20, padding: 12, flexDirection: 'row', gap: 8, elevation: 10 },
  emojiBtn: { padding: 8 },
  emojiText: { fontSize: 28 },
});
