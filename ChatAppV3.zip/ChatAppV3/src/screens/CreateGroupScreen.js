import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, FlatList, Alert, ActivityIndicator,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { COLORS, AVATAR_COLORS } from '../utils/theme';

export default function CreateGroupScreen({ navigation, route }) {
  const { userId } = route.params;
  const [groupName, setGroupName] = useState('');
  const [description, setDescription] = useState('');
  const [contacts, setContacts] = useState([]);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { loadContacts(); }, []);

  async function loadContacts() {
    const { data: msgs } = await supabase
      .from('messages')
      .select('sender_id, receiver_id, sender:profiles!messages_sender_id_fkey(id,full_name), receiver:profiles!messages_receiver_id_fkey(id,full_name)')
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`);

    if (!msgs) return;
    const map = {};
    msgs.forEach(m => {
      const partner = m.sender_id === userId ? m.receiver : m.sender;
      if (partner && partner.id !== userId) map[partner.id] = partner;
    });
    setContacts(Object.values(map));
  }

  function toggleSelect(id) {
    setSelected(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  }

  async function handleCreate() {
    if (!groupName.trim()) return Alert.alert('Hata', 'Grup adı gerekli.');
    if (selected.length === 0) return Alert.alert('Hata', 'En az bir kişi seç.');

    setLoading(true);
    try {
      const { data: group, error } = await supabase.from('groups').insert({
        name: groupName.trim(),
        description: description.trim() || null,
        created_by: userId,
        avatar_color: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
      }).select().single();

      if (error) throw error;

      const members = [userId, ...selected].map(uid => ({ group_id: group.id, user_id: uid }));
      await supabase.from('group_members').insert(members);

      navigation.replace('GroupChat', { userId, groupId: group.id, groupName: group.name });
    } catch {
      Alert.alert('Hata', 'Grup oluşturulamadı.');
    } finally {
      setLoading(false);
    }
  }

  function renderContact({ item }) {
    const isSelected = selected.includes(item.id);
    return (
      <TouchableOpacity style={styles.row} onPress={() => toggleSelect(item.id)}>
        <Avatar name={item.full_name} size={44} />
        <Text style={styles.contactName}>{item.full_name}</Text>
        <View style={[styles.checkbox, isSelected && styles.checkboxSelected]}>
          {isSelected && <Text style={styles.checkmark}>✓</Text>}
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Yeni Grup</Text>
      </View>

      <View style={styles.form}>
        <View style={styles.fieldWrap}>
          <Text style={styles.label}>GRUP ADI</Text>
          <TextInput style={styles.input} value={groupName} onChangeText={setGroupName} placeholder="Arkadaşlar, Aile..." placeholderTextColor="#bbb" />
        </View>
        <View style={styles.fieldWrap}>
          <Text style={styles.label}>AÇIKLAMA (OPSİYONEL)</Text>
          <TextInput style={styles.input} value={description} onChangeText={setDescription} placeholder="Grup hakkında..." placeholderTextColor="#bbb" />
        </View>
      </View>

      <Text style={styles.sectionTitle}>ÜYE EKLE ({selected.length} seçildi)</Text>

      <FlatList
        data={contacts}
        keyExtractor={item => item.id}
        renderItem={renderContact}
        style={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>Henüz mesajlaştığın kişi yok</Text>}
      />

      <TouchableOpacity style={styles.btn} onPress={handleCreate} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Grup Oluştur</Text>}
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: { backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 12, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  form: { padding: 16 },
  fieldWrap: { marginBottom: 14 },
  label: { fontSize: 11, fontWeight: '700', color: '#555', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { borderWidth: 1.5, borderColor: '#E8E8E8', borderRadius: 12, padding: 12, fontSize: 15, color: '#222', backgroundColor: '#FAFAFA' },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: '#555', paddingHorizontal: 16, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  list: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#F0F0F0' },
  contactName: { flex: 1, marginLeft: 12, fontSize: 15, fontWeight: '600', color: '#111' },
  checkbox: { width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: '#ddd', alignItems: 'center', justifyContent: 'center' },
  checkboxSelected: { backgroundColor: COLORS.accent, borderColor: COLORS.accent },
  checkmark: { color: '#fff', fontSize: 14, fontWeight: '800' },
  empty: { textAlign: 'center', color: '#aaa', padding: 40 },
  btn: { backgroundColor: COLORS.primary, margin: 16, borderRadius: 14, paddingVertical: 15, alignItems: 'center', elevation: 4 },
  btnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
