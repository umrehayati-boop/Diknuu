# ChatApp 💬 — Kurulum Rehberi

## 1. Supabase Kurulumu

1. `supabase.com` → projen → **SQL Editor**
2. `supabase_setup.sql` dosyasının içeriğini yapıştır → **Run**
3. **Settings → API** den şunları kopyala:
   - Project URL
   - anon public key

## 2. Supabase Bilgilerini Ekle

`src/utils/supabase.js` dosyasını aç:

```js
const SUPABASE_URL = 'BURAYA_PROJECT_URL';      // ← değiştir
const SUPABASE_ANON_KEY = 'BURAYA_ANON_KEY';    // ← değiştir
```

## 3. Bağımlılıkları Yükle

```bash
npm install
```

## 4. APK Oluştur

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

## Özellikler

- ✅ Gerçek anlık mesajlaşma (2 farklı telefon)
- ✅ E-posta ile kayıt & giriş
- ✅ Kişi arama (e-posta ile)
- ✅ Fotoğraf gönderme
- ✅ Push bildirimleri
- ✅ Online/offline durumu gerçek zamanlı
- ✅ Mesaj okundu bilgisi (mavi tik)
- ✅ Tarih ayraçları
