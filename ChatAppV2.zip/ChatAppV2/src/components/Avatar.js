import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { getInitials, getAvatarColor } from '../utils/theme';

export default function Avatar({ name = '', size = 44, color }) {
  const bg = color || getAvatarColor(name);
  return (
    <View style={[styles.container, {
      width: size, height: size,
      borderRadius: size / 2,
      backgroundColor: bg,
    }]}>
      <Text style={[styles.text, { fontSize: size * 0.36 }]}>
        {getInitials(name)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: 'center', justifyContent: 'center' },
  text: { color: '#fff', fontWeight: '800' },
});
