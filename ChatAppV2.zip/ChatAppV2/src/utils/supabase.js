import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ⚠️ BURAYA KENDİ SUPABASE BİLGİLERİNİ GİR
const SUPABASE_URL = 'https://dylxwyapkomtxepurnnb.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_VZGrHvbJqatWwYBo8RJ_zg_R500wAzn';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});
