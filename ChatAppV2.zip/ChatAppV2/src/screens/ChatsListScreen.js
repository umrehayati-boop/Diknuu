import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  TextInput, SafeAreaView, Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect } from '@react-navigation/native';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { registerForPushNotifications } from '../utils/notifications';
import { COLORS, formatTime, getAvatarColor } from '../utils/theme';

export default function ChatsListScreen({ navigation, route }) {
  const { userId } = route.params;
  const [profile, setProfile] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    loadProfile();
    registerForPushNotifications(userId);

    // Update online status
    supabase.from('profiles').update({ is_online: true, last_seen: new Date().toISOString() }).eq('id', userId);

    return () => {
      supabase.from('profiles').update({ is_online: false, last_seen: new Date().toISOString() }).eq('id', userId);
    };
  }, []);

  useFocusEffect(useCallback(() => {
    loadConversations();

    // Realtime: listen for new messages
    const channel = supabase
      .channel('messages_list')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `receiver_id=eq.${userId}`,
      }, () => loadConversations())
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [userId]));

  async function loadProfile() {
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).single();
    setProfile(data);
  }

  async function loadConversations() {
    // Get all messages involving this user
    const { data: msgs } = await supabase
      .from('messages')
      .select('*, sender:profiles!messages_sender_id_fkey(id,full_name,is_online), receiver:profiles!messages_receiver_id_fkey(id,full_name,is_online)')
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
      .order('created_at', { ascending: false });

    if (!msgs) return;

    // Group by conversation partner
    const map = {};
    msgs.forEach(msg => {
      const partner = msg.sender_id === userId ? msg.receiver : msg.sender;
      if (!partner) return;
      if (!map[partner.id]) {
        map[partner.id] = {
          partnerId: partner.id,
          partnerName: partner.full_name,
          isOnline: partner.is_online,
          lastMsg: msg,
          unread: 0,
        };
      }
      if (msg.receiver_id === userId && !msg.is_read) {
        map[partner.id].unread++;
      }
    });

    setConversations(Object.values(map));
  }

  function handleLogout() {
    Alert.alert('Çıkış', 'Çıkış yapmak istiyor musun?', [
      {
        text: 'Çıkış Yap', style: 'destructive', onPress: async () => {
          await supabase.from('profiles').update({ is_online: false }).eq('id', userId);
          await supabase.auth.signOut();
          navigation.replace('Auth');
        }
      },
      { text: 'İptal' },
    ]);
  }

  const filtered = conversations.filter(c =>
    !search || c.partnerName?.toLowerCase().includes(search.toLowerCase())
  );

  function renderItem({ item }) {
    const isMe = item.lastMsg?.sender_id === userId;
    const preview = item.lastMsg
      ? (isMe ? 'Sen: ' : '') + (item.lastMsg.image_url ? '📷 Fotoğraf' : item.lastMsg.content)
      : 'Sohbet başlat';

    return (
      <TouchableOpacity
        style={styles.row}
        onPress={() => navigation.navigate('Chat', {
          userId,
          partnerId: item.partnerId,
          partnerName: item.partnerName,
          senderName: profile?.full_name,
        })}
      >
        <View style={{ position: 'relative' }}>
          <Avatar name={item.partnerName} size={50} />
          {item.isOnline && <View style={styles.onlineDot} />}
        </View>
        <View style={styles.rowContent}>
          <View style={styles.rowTop}>
            <Text style={styles.contactName}>{item.partnerName}</Text>
            {item.lastMsg && (
              <Text style={[styles.time, item.unread > 0 && { color: COLORS.accent }]}>
                {formatTime(item.lastMsg.created_at)}
              </Text>
            )}
          </View>
          <View style={styles.rowBottom}>
            <Text style={styles.preview} numberOfLines={1}>{preview}</Text>
            {item.unread > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{item.unread}</Text>
              </View>
            )}
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Sohbetler</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('AddContact', { userId, senderName: profile?.full_name })}>
            <Text style={styles.iconText}>➕</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={handleLogout}>
            <Text style={styles.iconText}>⋮</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.searchWrap}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput style={styles.searchInput} placeholder="Ara..." placeholderTextColor="#aaa" value={search} onChangeText={setSearch} />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.partnerId}
        renderItem={renderItem}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>👥</Text>
            <Text style={styles.emptyTitle}>Henüz sohbet yok</Text>
            <Text style={styles.emptySub}>➕ ile kişi ekle ve konuşmaya başla</Text>
          </View>
        }
      />

      <TouchableOpacity style={styles.fab} onPress={() => navigation.navigate('AddContact', { userId, senderName: profile?.full_name })}>
        <Text style={styles.fabIcon}>✏️</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: { backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: '800' },
  headerActions: { flexDirection: 'row', gap: 6 },
  iconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  iconText: { fontSize: 16, color: '#fff' },
  searchWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F0F0F0', margin: 10, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 },
  searchIcon: { fontSize: 14, marginRight: 8 },
  searchInput: { flex: 1, fontSize: 14, color: '#222' },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#F0F0F0' },
  onlineDot: { position: 'absolute', bottom: 2, right: 2, width: 12, height: 12, borderRadius: 6, backgroundColor: COLORS.accent, borderWidth: 2, borderColor: '#fff' },
  rowContent: { flex: 1, marginLeft: 12 },
  rowTop: { flexDirection: 'row', justifyContent: 'space-between' },
  contactName: { fontWeight: '700', fontSize: 15, color: '#111' },
  time: { fontSize: 11, color: '#aaa' },
  rowBottom: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 3 },
  preview: { fontSize: 13, color: '#888', flex: 1 },
  badge: { backgroundColor: COLORS.accent, borderRadius: 10, minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  empty: { alignItems: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 52, marginBottom: 12 },
  emptyTitle: { fontSize: 16, fontWeight: '700', color: '#444', marginBottom: 6 },
  emptySub: { fontSize: 13, color: '#aaa' },
  fab: { position: 'absolute', bottom: 24, right: 20, width: 56, height: 56, borderRadius: 28, backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center', elevation: 6 },
  fabIcon: { fontSize: 22 },
});
