import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, ActivityIndicator, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { supabase } from '../utils/supabase';
import { COLORS } from '../utils/theme';

export default function AuthScreen({ navigation }) {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit() {
    if (!email.trim() || !password.trim()) return Alert.alert('Hata', 'E-posta ve şifre gerekli.');
    if (!email.includes('@')) return Alert.alert('Hata', 'Geçerli bir e-posta gir.');
    if (mode === 'register' && !name.trim()) return Alert.alert('Hata', 'İsim gerekli.');

    setLoading(true);
    try {
      if (mode === 'register') {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: name.trim() } },
        });
        if (error) return Alert.alert('Hata', error.message);
        // Profile created by DB trigger
        navigation.replace('Chats', { userId: data.user.id });
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (error) return Alert.alert('Hata', 'E-posta veya şifre hatalı.');
        navigation.replace('Chats', { userId: data.user.id });
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.logo}>💬</Text>
        <Text style={styles.appName}>ChatApp</Text>
        <Text style={styles.subtitle}>
          {mode === 'login' ? 'Hesabına giriş yap' : 'Yeni hesap oluştur'}
        </Text>
      </View>
      <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
        <View style={styles.toggle}>
          {['login', 'register'].map(m => (
            <TouchableOpacity key={m} style={[styles.toggleBtn, mode === m && styles.toggleActive]} onPress={() => setMode(m)}>
              <Text style={[styles.toggleText, mode === m && styles.toggleActiveText]}>
                {m === 'login' ? 'Giriş Yap' : 'Kayıt Ol'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        {mode === 'register' && <Field label="Adın Soyadın" value={name} onChange={setName} placeholder="Ahmet Yılmaz" />}
        <Field label="E-posta" value={email} onChange={setEmail} placeholder="ornek@mail.com" keyboardType="email-address" />
        <Field label="Şifre" value={password} onChange={setPassword} placeholder="••••••••" secure />
        <TouchableOpacity style={styles.btn} onPress={handleSubmit} disabled={loading}>
          {loading
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.btnText}>{mode === 'login' ? 'Giriş Yap' : 'Hesap Oluştur'}</Text>
          }
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Field({ label, value, onChange, placeholder, secure, keyboardType }) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor="#bbb"
        secureTextEntry={secure}
        keyboardType={keyboardType || 'default'}
        autoCapitalize="none"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: { backgroundColor: COLORS.primary, paddingTop: 60, paddingBottom: 28, paddingHorizontal: 24 },
  logo: { fontSize: 40, marginBottom: 6 },
  appName: { fontSize: 26, fontWeight: '800', color: '#fff' },
  subtitle: { fontSize: 13, color: 'rgba(255,255,255,0.75)', marginTop: 4 },
  form: { padding: 24 },
  toggle: { flexDirection: 'row', backgroundColor: '#F0F0F0', borderRadius: 12, padding: 4, marginBottom: 28 },
  toggleBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  toggleActive: { backgroundColor: '#fff', elevation: 2 },
  toggleText: { fontWeight: '700', fontSize: 14, color: '#888' },
  toggleActiveText: { color: COLORS.primary },
  fieldWrap: { marginBottom: 18 },
  label: { fontSize: 12, fontWeight: '700', color: '#555', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { borderWidth: 1.5, borderColor: '#E8E8E8', borderRadius: 12, padding: 13, fontSize: 15, color: '#222', backgroundColor: '#FAFAFA' },
  btn: { backgroundColor: COLORS.primary, borderRadius: 14, paddingVertical: 15, alignItems: 'center', marginTop: 8, elevation: 4 },
  btnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
