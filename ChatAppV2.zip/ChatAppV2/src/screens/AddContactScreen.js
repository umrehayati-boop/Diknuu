import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, Alert, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { COLORS } from '../utils/theme';

export default function AddContactScreen({ navigation, route }) {
  const { userId, senderName } = route.params;
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [found, setFound] = useState(null);

  async function handleSearch() {
    const trimmed = email.trim().toLowerCase();
    if (!trimmed || !trimmed.includes('@')) return Alert.alert('Hata', 'Geçerli bir e-posta gir.');

    setLoading(true);
    try {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', trimmed)
        .single();

      if (!data) {
        Alert.alert('Bulunamadı', 'Bu e-posta ile kayıtlı kullanıcı yok.');
        setFound(null);
      } else if (data.id === userId) {
        Alert.alert('Hata', 'Kendinizi ekleyemezsiniz.');
      } else {
        setFound(data);
      }
    } finally {
      setLoading(false);
    }
  }

  function handleStartChat() {
    if (!found) return;
    navigation.replace('Chat', {
      userId,
      partnerId: found.id,
      partnerName: found.full_name,
      senderName,
    });
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Yeni Sohbet</Text>
      </View>

      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.content}>
          <View style={styles.iconWrap}>
            <Text style={styles.bigIcon}>🔍</Text>
            <Text style={styles.iconSub}>Kişiyi e-posta ile ara</Text>
          </View>

          <View style={styles.searchRow}>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={v => { setEmail(v); setFound(null); }}
              placeholder="arkadas@mail.com"
              placeholderTextColor="#bbb"
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <TouchableOpacity style={styles.searchBtn} onPress={handleSearch} disabled={loading}>
              {loading ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.searchBtnText}>Ara</Text>}
            </TouchableOpacity>
          </View>

          {found && (
            <TouchableOpacity style={styles.resultCard} onPress={handleStartChat}>
              <Avatar name={found.full_name} size={52} />
              <View style={styles.resultInfo}>
                <Text style={styles.resultName}>{found.full_name}</Text>
                <Text style={styles.resultEmail}>{found.email}</Text>
                <Text style={styles.resultOnline}>{found.is_online ? '🟢 Çevrimiçi' : '⚫ Çevrimdışı'}</Text>
              </View>
              <Text style={styles.startChat}>Mesaj Gönder →</Text>
            </TouchableOpacity>
          )}

          <View style={styles.info}>
            <Text style={styles.infoTitle}>💡 Nasıl çalışır?</Text>
            <Text style={styles.infoText}>
              Arkadaşın da bu uygulamaya kayıtlı olmalı. E-postasını gir, bul ve mesajlaşmaya başla. Mesajlar anlık iletilir.
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  flex: { flex: 1 },
  header: { backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 12, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  content: { padding: 24 },
  iconWrap: { alignItems: 'center', marginBottom: 28 },
  bigIcon: { fontSize: 56, marginBottom: 8 },
  iconSub: { fontSize: 14, color: '#888' },
  searchRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  input: { flex: 1, borderWidth: 1.5, borderColor: '#E8E8E8', borderRadius: 12, padding: 13, fontSize: 15, color: '#222', backgroundColor: '#FAFAFA' },
  searchBtn: { backgroundColor: COLORS.primary, borderRadius: 12, paddingHorizontal: 18, justifyContent: 'center', alignItems: 'center' },
  searchBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  resultCard: { backgroundColor: '#F8FFF9', borderWidth: 1.5, borderColor: COLORS.accent, borderRadius: 16, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 20 },
  resultInfo: { flex: 1 },
  resultName: { fontWeight: '700', fontSize: 16, color: '#111' },
  resultEmail: { fontSize: 12, color: '#888', marginTop: 2 },
  resultOnline: { fontSize: 12, marginTop: 4 },
  startChat: { color: COLORS.primary, fontWeight: '700', fontSize: 13 },
  info: { backgroundColor: '#F8F8F8', borderRadius: 12, padding: 16 },
  infoTitle: { fontSize: 12, fontWeight: '700', color: '#555', marginBottom: 8 },
  infoText: { fontSize: 13, color: '#888', lineHeight: 20 },
});
