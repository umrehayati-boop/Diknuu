import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, FlatList, TextInput, TouchableOpacity,
  StyleSheet, SafeAreaView, KeyboardAvoidingView, Platform,
  Image, ActivityIndicator, Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { sendPushNotification } from '../utils/notifications';
import { COLORS, formatTime, formatDate } from '../utils/theme';

export default function ChatScreen({ navigation, route }) {
  const { userId, partnerId, partnerName, senderName } = route.params;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [partnerOnline, setPartnerOnline] = useState(false);
  const [uploading, setUploading] = useState(false);
  const flatRef = useRef(null);

  useEffect(() => {
    loadMessages();
    markAsRead();
    checkPartnerOnline();

    // Realtime messages
    const channel = supabase
      .channel(`chat_${[userId, partnerId].sort().join('_')}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `receiver_id=eq.${userId}`,
      }, payload => {
        if (payload.new.sender_id === partnerId) {
          setMessages(prev => [...prev, payload.new]);
          markAsRead();
          scrollToBottom();
        }
      })
      .subscribe();

    // Realtime partner online status
    const presenceChannel = supabase
      .channel(`presence_${partnerId}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'profiles',
        filter: `id=eq.${partnerId}`,
      }, payload => setPartnerOnline(payload.new.is_online))
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(presenceChannel);
    };
  }, []);

  function scrollToBottom() {
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  }

  async function loadMessages() {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .or(`and(sender_id.eq.${userId},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${userId})`)
      .order('created_at', { ascending: true });
    setMessages(data || []);
    scrollToBottom();
  }

  async function markAsRead() {
    await supabase
      .from('messages')
      .update({ is_read: true })
      .eq('sender_id', partnerId)
      .eq('receiver_id', userId)
      .eq('is_read', false);
  }

  async function checkPartnerOnline() {
    const { data } = await supabase.from('profiles').select('is_online').eq('id', partnerId).single();
    setPartnerOnline(data?.is_online || false);
  }

  async function handleSend(imageUrl = null) {
    const content = text.trim();
    if (!content && !imageUrl) return;
    setText('');

    const { data, error } = await supabase.from('messages').insert({
      sender_id: userId,
      receiver_id: partnerId,
      content: content || null,
      image_url: imageUrl || null,
      is_read: false,
    }).select().single();

    if (!error && data) {
      setMessages(prev => [...prev, data]);
      scrollToBottom();
      // Push notification
      await sendPushNotification(partnerId, senderName, imageUrl ? '📷 Fotoğraf' : content);
    }
  }

  async function handleImagePick() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return Alert.alert('İzin gerekli', 'Fotoğraf erişimi için izin ver.');

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
    });

    if (result.canceled) return;

    setUploading(true);
    try {
      const uri = result.assets[0].uri;
      const fileName = `${userId}_${Date.now()}.jpg`;
      const formData = new FormData();
      formData.append('file', { uri, name: fileName, type: 'image/jpeg' });

      const { data, error } = await supabase.storage
        .from('chat-images')
        .upload(fileName, formData, { contentType: 'image/jpeg' });

      if (error) throw error;

      const { data: urlData } = supabase.storage.from('chat-images').getPublicUrl(fileName);
      await handleSend(urlData.publicUrl);
    } catch (e) {
      Alert.alert('Hata', 'Fotoğraf gönderilemedi.');
    } finally {
      setUploading(false);
    }
  }

  function buildItems() {
    const items = [];
    let lastDate = null;
    messages.forEach(m => {
      const d = formatDate(m.created_at);
      if (d !== lastDate) {
        items.push({ type: 'date', id: 'date_' + m.id, label: d });
        lastDate = d;
      }
      items.push({ type: 'msg', ...m });
    });
    return items;
  }

  function renderItem({ item }) {
    if (item.type === 'date') {
      return (
        <View style={styles.dateSep}>
          <Text style={styles.dateLabel}>{item.label}</Text>
        </View>
      );
    }
    const isMe = item.sender_id === userId;
    return (
      <View style={[styles.bubbleWrap, isMe && styles.myWrap]}>
        <View style={[styles.bubble, isMe ? styles.myBubble : styles.theirBubble]}>
          {item.image_url ? (
            <Image source={{ uri: item.image_url }} style={styles.msgImage} resizeMode="cover" />
          ) : (
            <Text style={styles.msgText}>{item.content}</Text>
          )}
          <View style={styles.msgMeta}>
            <Text style={styles.msgTime}>{formatTime(item.created_at)}</Text>
            {isMe && <Text style={[styles.tick, item.is_read && styles.tickRead]}> ✓✓</Text>}
          </View>
        </View>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Avatar name={partnerName} size={38} />
        <View style={styles.headerInfo}>
          <Text style={styles.headerName}>{partnerName}</Text>
          <Text style={styles.headerSub}>{partnerOnline ? '🟢 çevrimiçi' : 'çevrimdışı'}</Text>
        </View>
      </View>

      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          ref={flatRef}
          data={buildItems()}
          keyExtractor={item => item.id?.toString()}
          renderItem={renderItem}
          style={styles.messageList}
          contentContainerStyle={styles.messageContent}
          onContentSizeChange={scrollToBottom}
        />

        {uploading && (
          <View style={styles.uploadingBar}>
            <ActivityIndicator color={COLORS.accent} size="small" />
            <Text style={styles.uploadingText}>Fotoğraf yükleniyor...</Text>
          </View>
        )}

        <View style={styles.inputBar}>
          <TouchableOpacity onPress={handleImagePick} style={styles.attachBtn}>
            <Text style={styles.attachIcon}>📷</Text>
          </TouchableOpacity>
          <View style={styles.inputWrap}>
            <TextInput
              style={styles.textInput}
              value={text}
              onChangeText={setText}
              placeholder="Mesaj yaz..."
              placeholderTextColor="#aaa"
              multiline
            />
          </View>
          <TouchableOpacity
            style={[styles.sendBtn, !text.trim() && styles.sendBtnInactive]}
            onPress={() => handleSend()}
          >
            <Text style={styles.sendIcon}>{text.trim() ? '➤' : '🎤'}</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  flex: { flex: 1 },
  header: { backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 8, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerInfo: { flex: 1 },
  headerName: { color: '#fff', fontWeight: '700', fontSize: 16 },
  headerSub: { color: 'rgba(255,255,255,0.75)', fontSize: 12 },
  messageList: { flex: 1, backgroundColor: COLORS.chatBg },
  messageContent: { padding: 10 },
  dateSep: { alignItems: 'center', marginVertical: 10 },
  dateLabel: { backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 4, fontSize: 12, color: '#555', fontWeight: '600' },
  bubbleWrap: { marginBottom: 3, alignItems: 'flex-start' },
  myWrap: { alignItems: 'flex-end' },
  bubble: { maxWidth: '75%', padding: 9, paddingHorizontal: 12, borderRadius: 16, elevation: 1 },
  myBubble: { backgroundColor: COLORS.myBubble, borderBottomRightRadius: 4 },
  theirBubble: { backgroundColor: '#fff', borderBottomLeftRadius: 4 },
  msgText: { fontSize: 15, color: '#111', lineHeight: 20 },
  msgImage: { width: 200, height: 200, borderRadius: 10 },
  msgMeta: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 3, alignItems: 'center' },
  msgTime: { fontSize: 11, color: '#888' },
  tick: { fontSize: 11, color: '#aaa' },
  tickRead: { color: '#53BDEB' },
  uploadingBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', padding: 8, gap: 8 },
  uploadingText: { fontSize: 13, color: '#888' },
  inputBar: { backgroundColor: '#F0F0F0', flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 8, paddingVertical: 6, gap: 8 },
  attachBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', elevation: 1 },
  attachIcon: { fontSize: 20 },
  inputWrap: { flex: 1, backgroundColor: '#fff', borderRadius: 24, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 8, elevation: 1 },
  textInput: { flex: 1, fontSize: 15, color: '#222', maxHeight: 100 },
  sendBtn: { width: 46, height: 46, borderRadius: 23, backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center', elevation: 3 },
  sendBtnInactive: { backgroundColor: '#ccc', elevation: 0 },
  sendIcon: { fontSize: 18, color: '#fff' },
});
