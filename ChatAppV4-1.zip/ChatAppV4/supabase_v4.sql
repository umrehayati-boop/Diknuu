-- =============================================
-- CHATAPP V4 SQL - Supabase SQL Editor'e yapıştır
-- =============================================

-- Durumlar (Stories)
CREATE TABLE IF NOT EXISTS statuses (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  content TEXT,
  image_url TEXT,
  expires_at TIMESTAMPTZ DEFAULT (now() + interval '24 hours'),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Durum görüntülemeler
CREATE TABLE IF NOT EXISTS status_views (
  id BIGSERIAL PRIMARY KEY,
  status_id BIGINT REFERENCES statuses(id) ON DELETE CASCADE,
  viewer_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  viewed_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(status_id, viewer_id)
);

-- Arşivlenmiş sohbetler
CREATE TABLE IF NOT EXISTS archived_chats (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  partner_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  archived_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, partner_id)
);

-- Yazıyor durumu
CREATE TABLE IF NOT EXISTS typing_status (
  id BIGSERIAL PRIMARY KEY,
  sender_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  receiver_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  is_typing BOOLEAN DEFAULT false,
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(sender_id, receiver_id)
);

-- Süreli mesajlar ayarı
CREATE TABLE IF NOT EXISTS vanish_settings (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  partner_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  duration TEXT DEFAULT 'off', -- off | 24h | 7d | 90d
  UNIQUE(user_id, partner_id)
);

-- Profiles tablosuna last_seen_visible ekle
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_seen_visible BOOLEAN DEFAULT true;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS avatar_url TEXT;

-- Mesajlar tablosuna reply ve pinned ekle
ALTER TABLE messages ADD COLUMN IF NOT EXISTS reply_to BIGINT REFERENCES messages(id);
ALTER TABLE messages ADD COLUMN IF NOT EXISTS is_pinned BOOLEAN DEFAULT false;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ;

-- RLS
ALTER TABLE statuses ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE archived_chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE typing_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE vanish_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "statuses_select" ON statuses FOR SELECT USING (true);
CREATE POLICY "statuses_insert" ON statuses FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "statuses_delete" ON statuses FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "status_views_select" ON status_views FOR SELECT USING (true);
CREATE POLICY "status_views_insert" ON status_views FOR INSERT WITH CHECK (auth.uid() = viewer_id);

CREATE POLICY "archived_select" ON archived_chats FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "archived_insert" ON archived_chats FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "archived_delete" ON archived_chats FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "typing_select" ON typing_status FOR SELECT USING (true);
CREATE POLICY "typing_insert" ON typing_status FOR INSERT WITH CHECK (auth.uid() = sender_id);
CREATE POLICY "typing_update" ON typing_status FOR UPDATE USING (auth.uid() = sender_id);
CREATE POLICY "typing_delete" ON typing_status FOR DELETE USING (auth.uid() = sender_id);

CREATE POLICY "vanish_select" ON vanish_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "vanish_insert" ON vanish_settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "vanish_update" ON vanish_settings FOR UPDATE USING (auth.uid() = user_id);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE statuses;
ALTER PUBLICATION supabase_realtime ADD TABLE typing_status;
