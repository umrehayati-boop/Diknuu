export const LIGHT_THEME = {
  primary: '#075E54',
  primaryLight: '#128C7E',
  accent: '#25D366',
  chatBg: '#ECE5DD',
  myBubble: '#DCF8C6',
  theirBubble: '#FFFFFF',
  background: '#FFFFFF',
  surface: '#F7F7F7',
  text: '#111111',
  subText: '#888888',
  border: '#E8E8E8',
  inputBg: '#F0F0F0',
  danger: '#FF3B30',
  headerText: '#FFFFFF',
  tabBar: '#FFFFFF',
};

export const DARK_THEME = {
  primary: '#075E54',
  primaryLight: '#128C7E',
  accent: '#25D366',
  chatBg: '#0D1117',
  myBubble: '#005C4B',
  theirBubble: '#1F2C34',
  background: '#111B21',
  surface: '#1F2C34',
  text: '#E9EDEF',
  subText: '#8696A0',
  border: '#2A3942',
  inputBg: '#1F2C34',
  danger: '#FF3B30',
  headerText: '#FFFFFF',
  tabBar: '#1F2C34',
};

export const COLORS = LIGHT_THEME;

export const AVATAR_COLORS = [
  '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4',
  '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE',
  '#85C1E9', '#F0A500',
];

export const CHAT_WALLPAPERS = [
  { id: 'default', color: '#ECE5DD', dark: '#0D1117', label: 'Varsayılan' },
  { id: 'blue', color: '#E3F2FD', dark: '#0A1628', label: 'Mavi' },
  { id: 'green', color: '#E8F5E9', dark: '#0A1F0A', label: 'Yeşil' },
  { id: 'purple', color: '#F3E5F5', dark: '#1A0A2E', label: 'Mor' },
  { id: 'pink', color: '#FCE4EC', dark: '#2E0A1A', label: 'Pembe' },
  { id: 'dark', color: '#263238', dark: '#0A0A0A', label: 'Koyu' },
];

export const NOTIFICATION_SOUNDS = [
  { id: 'default', label: '🔔 Varsayılan' },
  { id: 'ding', label: '🎵 Ding' },
  { id: 'pop', label: '💬 Pop' },
  { id: 'none', label: '🔇 Sessiz' },
];

export function getAvatarColor(name = '') {
  return AVATAR_COLORS[(name.charCodeAt(0) || 0) % AVATAR_COLORS.length];
}

export function getInitials(name = '') {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

export function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
}

export function formatDate(ts) {
  const d = new Date(ts);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return 'Bugün';
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return 'Dün';
  return d.toLocaleDateString('tr-TR');
}
