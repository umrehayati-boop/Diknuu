import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LIGHT_THEME, DARK_THEME } from '../utils/theme';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [darkMode, setDarkMode] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [notificationSound, setNotificationSound] = useState('default');
  const [fontSize, setFontSize] = useState('medium'); // small | medium | large
  const [wallpaper, setWallpaper] = useState('default');
  const [lastSeenVisible, setLastSeenVisible] = useState(true);

  const theme = darkMode ? DARK_THEME : LIGHT_THEME;

  const fontSizeMap = { small: 13, medium: 15, large: 17 };
  const msgFontSize = fontSizeMap[fontSize];

  useEffect(() => { loadSettings(); }, []);

  async function loadSettings() {
    try {
      const s = await AsyncStorage.getItem('app_settings');
      if (s) {
        const parsed = JSON.parse(s);
        setDarkMode(parsed.darkMode ?? false);
        setSoundEnabled(parsed.soundEnabled ?? true);
        setNotificationSound(parsed.notificationSound ?? 'default');
        setFontSize(parsed.fontSize ?? 'medium');
        setWallpaper(parsed.wallpaper ?? 'default');
        setLastSeenVisible(parsed.lastSeenVisible ?? true);
      }
    } catch {}
  }

  async function saveSettings(key, val) {
    try {
      const s = await AsyncStorage.getItem('app_settings');
      const parsed = s ? JSON.parse(s) : {};
      parsed[key] = val;
      await AsyncStorage.setItem('app_settings', JSON.stringify(parsed));
    } catch {}
  }

  function toggleDarkMode() {
    const val = !darkMode;
    setDarkMode(val);
    saveSettings('darkMode', val);
  }

  function toggleSound() {
    const val = !soundEnabled;
    setSoundEnabled(val);
    saveSettings('soundEnabled', val);
  }

  function changeNotificationSound(val) {
    setNotificationSound(val);
    saveSettings('notificationSound', val);
  }

  function changeFontSize(val) {
    setFontSize(val);
    saveSettings('fontSize', val);
  }

  function changeWallpaper(val) {
    setWallpaper(val);
    saveSettings('wallpaper', val);
  }

  function toggleLastSeen() {
    const val = !lastSeenVisible;
    setLastSeenVisible(val);
    saveSettings('lastSeenVisible', val);
  }

  return (
    <AppContext.Provider value={{
      theme, darkMode, toggleDarkMode,
      soundEnabled, toggleSound,
      notificationSound, changeNotificationSound,
      fontSize, msgFontSize, changeFontSize,
      wallpaper, changeWallpaper,
      lastSeenVisible, toggleLastSeen,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
