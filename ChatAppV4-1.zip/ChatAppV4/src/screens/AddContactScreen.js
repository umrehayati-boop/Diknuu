import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, Alert, KeyboardAvoidingView, Platform, ActivityIndicator, Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { useApp } from '../context/AppContext';

export default function AddContactScreen({ navigation, route }) {
  const { userId, senderName } = route.params;
  const { theme } = useApp();
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [searched, setSearched] = useState(false);

  async function handleSearch() {
    const trimmed = query.trim();
    if (!trimmed) return Alert.alert('Hata', 'İsim veya e-posta gir.');

    setLoading(true);
    setSearched(true);
    try {
      const isEmail = trimmed.includes('@');
      let q = supabase.from('profiles').select('*').neq('id', userId);

      if (isEmail) {
        q = q.eq('email', trimmed.toLowerCase());
      } else {
        q = q.ilike('full_name', `%${trimmed}%`);
      }

      const { data } = await q.limit(10);
      setResults(data || []);
    } finally {
      setLoading(false);
    }
  }

  function handleStartChat(contact) {
    navigation.replace('Chat', {
      userId,
      partnerId: contact.id,
      partnerName: contact.full_name,
      senderName,
    });
  }

  function handlePreview(contact) {
    Alert.alert(
      contact.full_name,
      `📧 ${contact.email}\n${contact.is_online ? '🟢 Çevrimiçi' : '⚫ Çevrimdışı'}`,
      [
        { text: 'Mesaj Gönder', onPress: () => handleStartChat(contact) },
        { text: 'İptal', style: 'cancel' },
      ]
    );
  }

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar style="light" />
      <View style={[styles.header, { backgroundColor: theme.primary }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Yeni Sohbet</Text>
      </View>

      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.content}>
          <View style={styles.iconWrap}>
            <Text style={styles.bigIcon}>🔍</Text>
            <Text style={[styles.iconSub, { color: theme.subText }]}>İsim veya e-posta ile ara</Text>
          </View>

          <View style={styles.searchRow}>
            <TextInput
              style={[styles.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.surface }]}
              value={query}
              onChangeText={v => { setQuery(v); setResults([]); setSearched(false); }}
              placeholder="İsim veya e-posta..."
              placeholderTextColor={theme.subText}
              autoCapitalize="none"
              onSubmitEditing={handleSearch}
            />
            <TouchableOpacity style={[styles.searchBtn, { backgroundColor: theme.primary }]} onPress={handleSearch} disabled={loading}>
              {loading ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.searchBtnText}>Ara</Text>}
            </TouchableOpacity>
          </View>

          {results.map(contact => (
            <TouchableOpacity key={contact.id} style={[styles.resultCard, { backgroundColor: theme.surface, borderColor: theme.accent }]} onPress={() => handleStartChat(contact)} onLongPress={() => handlePreview(contact)}>
              <View style={{ position: 'relative' }}>
                <Avatar name={contact.full_name} size={52} />
                {contact.is_online && <View style={styles.onlineDot} />}
              </View>
              <View style={styles.resultInfo}>
                <Text style={[styles.resultName, { color: theme.text }]}>{contact.full_name}</Text>
                <Text style={[styles.resultEmail, { color: theme.subText }]}>{contact.email}</Text>
                <Text style={styles.resultOnline}>{contact.is_online ? '🟢 Çevrimiçi' : '⚫ Çevrimdışı'}</Text>
              </View>
              <View style={styles.resultActions}>
                <TouchableOpacity style={[styles.previewBtn, { borderColor: theme.border }]} onPress={() => handlePreview(contact)}>
                  <Text style={[styles.previewBtnText, { color: theme.subText }]}>👁️</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.chatBtn, { backgroundColor: theme.accent }]} onPress={() => handleStartChat(contact)}>
                  <Text style={styles.chatBtnText}>💬</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))}

          {searched && results.length === 0 && !loading && (
            <View style={styles.noResult}>
              <Text style={styles.noResultIcon}>😕</Text>
              <Text style={[styles.noResultText, { color: theme.subText }]}>Kullanıcı bulunamadı</Text>
            </View>
          )}

          <View style={[styles.info, { backgroundColor: theme.surface }]}>
            <Text style={[styles.infoTitle, { color: theme.subText }]}>💡 İPUCU</Text>
            <Text style={[styles.infoText, { color: theme.subText }]}>
              İsimle arama yapabilirsin! Örn: "Ahmet" yazarsan tüm Ahmetler çıkar. Uzun bas → kişiyi önizle.
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  flex: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 12, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  content: { padding: 24 },
  iconWrap: { alignItems: 'center', marginBottom: 24 },
  bigIcon: { fontSize: 48, marginBottom: 6 },
  iconSub: { fontSize: 14 },
  searchRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  input: { flex: 1, borderWidth: 1.5, borderRadius: 12, padding: 12, fontSize: 15 },
  searchBtn: { borderRadius: 12, paddingHorizontal: 18, justifyContent: 'center', alignItems: 'center' },
  searchBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  resultCard: { borderWidth: 1.5, borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  onlineDot: { position: 'absolute', bottom: 2, right: 2, width: 12, height: 12, borderRadius: 6, backgroundColor: '#25D366', borderWidth: 2, borderColor: '#fff' },
  resultInfo: { flex: 1 },
  resultName: { fontWeight: '700', fontSize: 16 },
  resultEmail: { fontSize: 12, marginTop: 2 },
  resultOnline: { fontSize: 12, marginTop: 4 },
  resultActions: { flexDirection: 'row', gap: 8 },
  previewBtn: { width: 36, height: 36, borderRadius: 18, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  previewBtnText: { fontSize: 16 },
  chatBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  chatBtnText: { fontSize: 18 },
  noResult: { alignItems: 'center', paddingVertical: 30 },
  noResultIcon: { fontSize: 40, marginBottom: 8 },
  noResultText: { fontSize: 14 },
  info: { marginTop: 20, borderRadius: 12, padding: 16 },
  infoTitle: { fontSize: 12, fontWeight: '700', marginBottom: 8 },
  infoText: { fontSize: 13, lineHeight: 20 },
});
