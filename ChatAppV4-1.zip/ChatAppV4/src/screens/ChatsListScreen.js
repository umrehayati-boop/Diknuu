import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  TextInput, SafeAreaView, Alert, AppState,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect } from '@react-navigation/native';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { registerForPushNotifications } from '../utils/notifications';
import { formatTime, AVATAR_COLORS } from '../utils/theme';
import { useApp } from '../context/AppContext';

export default function ChatsListScreen({ navigation, route }) {
  const { userId } = route.params;
  const { theme, darkMode } = useApp();
  const [profile, setProfile] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [archivedIds, setArchivedIds] = useState([]);
  const [groups, setGroups] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('chats');

  useEffect(() => {
    loadProfile();
    registerForPushNotifications(userId);
    setOnline(true);

    const sub = AppState.addEventListener('change', state => setOnline(state === 'active'));
    return () => { setOnline(false); sub.remove(); };
  }, []);

  async function setOnline(val) {
    await supabase.from('profiles').update({ is_online: val, last_seen: new Date().toISOString() }).eq('id', userId);
  }

  useFocusEffect(useCallback(() => {
    loadConversations();
    loadGroups();
    loadStatuses();
    loadArchived();
    setOnline(true);

    const channel = supabase.channel('msgs_' + userId)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `receiver_id=eq.${userId}` }, () => loadConversations())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'statuses' }, () => loadStatuses())
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [userId]));

  async function loadProfile() {
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).single();
    setProfile(data);
  }

  async function loadArchived() {
    const { data } = await supabase.from('archived_chats').select('partner_id').eq('user_id', userId);
    setArchivedIds(data?.map(d => d.partner_id) || []);
  }

  async function loadConversations() {
    const { data: msgs } = await supabase
      .from('messages')
      .select('*, sender:profiles!messages_sender_id_fkey(id,full_name,is_online,avatar_url), receiver:profiles!messages_receiver_id_fkey(id,full_name,is_online,avatar_url)')
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
      .order('created_at', { ascending: false });

    if (!msgs) return;
    const map = {};
    msgs.forEach(msg => {
      const partner = msg.sender_id === userId ? msg.receiver : msg.sender;
      if (!partner) return;
      if (!map[partner.id]) {
        map[partner.id] = { partnerId: partner.id, partnerName: partner.full_name, isOnline: partner.is_online, avatarUrl: partner.avatar_url, lastMsg: msg, unread: 0 };
      }
      if (msg.receiver_id === userId && !msg.is_read) map[partner.id].unread++;
    });
    setConversations(Object.values(map));
  }

  async function loadGroups() {
    const { data } = await supabase.from('group_members').select('group_id, groups(*)').eq('user_id', userId);
    if (data) setGroups(data.map(d => d.groups).filter(Boolean));
  }

  async function loadStatuses() {
    const { data } = await supabase
      .from('statuses')
      .select('*, user:profiles(id,full_name,avatar_url)')
      .gt('expires_at', new Date().toISOString())
      .neq('user_id', userId)
      .order('created_at', { ascending: false });
    setStatuses(data || []);
  }

  async function archiveChat(partnerId) {
    const isArchived = archivedIds.includes(partnerId);
    if (isArchived) {
      await supabase.from('archived_chats').delete().eq('user_id', userId).eq('partner_id', partnerId);
      setArchivedIds(prev => prev.filter(id => id !== partnerId));
    } else {
      await supabase.from('archived_chats').insert({ user_id: userId, partner_id: partnerId });
      setArchivedIds(prev => [...prev, partnerId]);
    }
  }

  function handleLogout() {
    Alert.alert('Çıkış', 'Çıkış yapmak istiyor musun?', [
      {
        text: 'Çıkış Yap', style: 'destructive', onPress: async () => {
          await setOnline(false);
          await supabase.auth.signOut();
          navigation.replace('Auth');
        }
      },
      { text: 'İptal' },
    ]);
  }

  const activeChats = conversations.filter(c => !archivedIds.includes(c.partnerId));
  const archivedChats = conversations.filter(c => archivedIds.includes(c.partnerId));

  const filteredChats = (tab === 'archived' ? archivedChats : activeChats)
    .filter(c => !search || c.partnerName?.toLowerCase().includes(search.toLowerCase()));

  const filteredGroups = groups.filter(g => !search || g.name?.toLowerCase().includes(search.toLowerCase()));

  // Unique status users
  const statusUsers = [];
  const seenIds = new Set();
  statuses.forEach(s => {
    if (!seenIds.has(s.user_id)) { seenIds.add(s.user_id); statusUsers.push(s); }
  });

  function renderChat({ item }) {
    const isMe = item.lastMsg?.sender_id === userId;
    const preview = item.lastMsg
      ? (isMe ? 'Sen: ' : '') + (item.lastMsg.image_url ? '📷 Fotoğraf' : item.lastMsg.is_deleted ? '🚫 Silindi' : item.lastMsg.content || '')
      : 'Sohbet başlat';

    return (
      <TouchableOpacity
        style={[styles.row, { borderBottomColor: theme.border }]}
        onPress={() => navigation.navigate('Chat', { userId, partnerId: item.partnerId, partnerName: item.partnerName, senderName: profile?.full_name })}
        onLongPress={() => Alert.alert(
          item.partnerName,
          archivedIds.includes(item.partnerId) ? 'Arşivden çıkar?' : 'Arşive al?',
          [{ text: 'Evet', onPress: () => archiveChat(item.partnerId) }, { text: 'İptal' }]
        )}
      >
        <View style={{ position: 'relative' }}>
          <Avatar name={item.partnerName} size={50} avatarUrl={item.avatarUrl} />
          {item.isOnline && <View style={styles.onlineDot} />}
        </View>
        <View style={styles.rowContent}>
          <View style={styles.rowTop}>
            <Text style={[styles.contactName, { color: theme.text }]}>{item.partnerName}</Text>
            {item.lastMsg && <Text style={[styles.time, item.unread > 0 && { color: theme.accent }]}>{formatTime(item.lastMsg.created_at)}</Text>}
          </View>
          <View style={styles.rowBottom}>
            <Text style={[styles.preview, { color: theme.subText }]} numberOfLines={1}>{preview}</Text>
            {item.unread > 0 && <View style={[styles.badge, { backgroundColor: theme.accent }]}><Text style={styles.badgeText}>{item.unread}</Text></View>}
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  function renderGroup({ item }) {
    return (
      <TouchableOpacity style={[styles.row, { borderBottomColor: theme.border }]} onPress={() => navigation.navigate('GroupChat', { userId, groupId: item.id, groupName: item.name, senderName: profile?.full_name })}>
        <View style={[styles.groupAvatar, { backgroundColor: item.avatar_color || theme.accent }]}>
          <Text style={styles.groupAvatarText}>👥</Text>
        </View>
        <View style={styles.rowContent}>
          <Text style={[styles.contactName, { color: theme.text }]}>{item.name}</Text>
          <Text style={[styles.preview, { color: theme.subText }]} numberOfLines={1}>{item.description || 'Grup sohbeti'}</Text>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar style={darkMode ? 'light' : 'light'} />

      {/* Header */}
      <View style={[styles.header, { backgroundColor: theme.primary }]}>
        <Text style={styles.headerTitle}>ChatApp</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('Status', { userId })}>
            <Text style={styles.iconText}>🔵</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('Profile', { userId })}>
            <Text style={styles.iconText}>👤</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('Settings', { userId })}>
            <Text style={styles.iconText}>⚙️</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={handleLogout}>
            <Text style={styles.iconText}>⋮</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Status bar */}
      {tab === 'chats' && statusUsers.length > 0 && (
        <View style={[styles.statusBar, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
          <FlatList
            horizontal
            data={statusUsers}
            keyExtractor={item => item.id?.toString()}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ padding: 8, gap: 12 }}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.statusItem} onPress={() => navigation.navigate('StatusView', { statusUserId: item.user_id, userId })}>
                <View style={[styles.statusRing, { borderColor: theme.accent }]}>
                  <Avatar name={item.user?.full_name || ''} size={46} />
                </View>
                <Text style={[styles.statusName, { color: theme.text }]} numberOfLines={1}>{item.user?.full_name?.split(' ')[0]}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      )}

      {/* Tabs */}
      <View style={[styles.tabs, { backgroundColor: theme.primary }]}>
        {['chats', 'groups', 'archived'].map(t => (
          <TouchableOpacity key={t} style={[styles.tab, tab === t && styles.tabActive]} onPress={() => setTab(t)}>
            <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>
              {t === 'chats' ? 'Sohbetler' : t === 'groups' ? 'Gruplar' : `📦 Arşiv (${archivedChats.length})`}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Search */}
      <View style={[styles.searchWrap, { backgroundColor: theme.inputBg }]}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput style={[styles.searchInput, { color: theme.text }]} placeholder="Ara..." placeholderTextColor={theme.subText} value={search} onChangeText={setSearch} />
      </View>

      {tab === 'groups' ? (
        <FlatList data={filteredGroups} keyExtractor={item => item.id?.toString()} renderItem={renderGroup}
          ListEmptyComponent={<View style={styles.empty}><Text style={styles.emptyIcon}>👥</Text><Text style={[styles.emptyTitle, { color: theme.text }]}>Henüz grup yok</Text></View>} />
      ) : (
        <FlatList data={filteredChats} keyExtractor={item => item.partnerId} renderItem={renderChat}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyIcon}>{tab === 'archived' ? '📦' : '💬'}</Text>
              <Text style={[styles.emptyTitle, { color: theme.text }]}>{tab === 'archived' ? 'Arşiv boş' : 'Henüz sohbet yok'}</Text>
              <Text style={[styles.emptySub, { color: theme.subText }]}>{tab === 'archived' ? 'Sohbete uzun bas → arşive al' : '➕ ile kişi ekle'}</Text>
            </View>
          }
        />
      )}

      {/* FAB */}
      {tab !== 'archived' && (
        <TouchableOpacity style={[styles.fab, { backgroundColor: theme.accent }]}
          onPress={() => tab === 'chats' ? navigation.navigate('AddContact', { userId, senderName: profile?.full_name }) : navigation.navigate('CreateGroup', { userId })}>
          <Text style={styles.fabIcon}>{tab === 'chats' ? '✏️' : '➕'}</Text>
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: '800' },
  headerActions: { flexDirection: 'row', gap: 4 },
  iconBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  iconText: { fontSize: 15, color: '#fff' },
  statusBar: { borderBottomWidth: StyleSheet.hairlineWidth },
  statusItem: { alignItems: 'center', width: 60 },
  statusRing: { borderWidth: 2.5, borderRadius: 27, padding: 2, marginBottom: 4 },
  statusName: { fontSize: 11, textAlign: 'center' },
  tabs: { flexDirection: 'row' },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: '#fff' },
  tabText: { color: 'rgba(255,255,255,0.6)', fontWeight: '600', fontSize: 12 },
  tabTextActive: { color: '#fff' },
  searchWrap: { flexDirection: 'row', alignItems: 'center', margin: 10, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 },
  searchIcon: { fontSize: 14, marginRight: 8 },
  searchInput: { flex: 1, fontSize: 14 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  onlineDot: { position: 'absolute', bottom: 2, right: 2, width: 12, height: 12, borderRadius: 6, backgroundColor: '#25D366', borderWidth: 2, borderColor: '#fff' },
  groupAvatar: { width: 50, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center' },
  groupAvatarText: { fontSize: 22 },
  rowContent: { flex: 1, marginLeft: 12 },
  rowTop: { flexDirection: 'row', justifyContent: 'space-between' },
  contactName: { fontWeight: '700', fontSize: 15 },
  time: { fontSize: 11, color: '#aaa' },
  rowBottom: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 3 },
  preview: { fontSize: 13, flex: 1 },
  badge: { borderRadius: 10, minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  empty: { alignItems: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 52, marginBottom: 12 },
  emptyTitle: { fontSize: 16, fontWeight: '700', marginBottom: 6 },
  emptySub: { fontSize: 13 },
  fab: { position: 'absolute', bottom: 24, right: 20, width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', elevation: 6 },
  fabIcon: { fontSize: 22 },
});
