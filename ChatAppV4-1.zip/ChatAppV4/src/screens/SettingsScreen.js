import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Switch, Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useApp } from '../context/AppContext';
import { CHAT_WALLPAPERS, NOTIFICATION_SOUNDS } from '../utils/theme';

export default function SettingsScreen({ navigation, route }) {
  const { userId } = route.params;
  const {
    theme, darkMode, toggleDarkMode,
    soundEnabled, toggleSound,
    notificationSound, changeNotificationSound,
    fontSize, changeFontSize,
    wallpaper, changeWallpaper,
    lastSeenVisible, toggleLastSeen,
  } = useApp();

  function Section({ title, children }) {
    return (
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.accent }]}>{title}</Text>
        <View style={[styles.sectionCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          {children}
        </View>
      </View>
    );
  }

  function SettingRow({ icon, label, right, onPress, danger }) {
    return (
      <TouchableOpacity style={[styles.row, { borderBottomColor: theme.border }]} onPress={onPress} disabled={!onPress}>
        <Text style={styles.rowIcon}>{icon}</Text>
        <Text style={[styles.rowLabel, { color: danger ? theme.danger : theme.text }]}>{label}</Text>
        <View style={styles.rowRight}>{right}</View>
      </TouchableOpacity>
    );
  }

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar style="light" />
      <View style={[styles.header, { backgroundColor: theme.primary }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Ayarlar</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>

        <Section title="GÖRÜNÜM">
          <SettingRow icon="🌙" label="Karanlık Mod" right={
            <Switch value={darkMode} onValueChange={toggleDarkMode} trackColor={{ true: theme.accent }} />
          } />
          <SettingRow icon="🔤" label="Yazı Boyutu" right={
            <View style={styles.fontBtns}>
              {['small', 'medium', 'large'].map(f => (
                <TouchableOpacity key={f} style={[styles.fontBtn, fontSize === f && { backgroundColor: theme.accent }]} onPress={() => changeFontSize(f)}>
                  <Text style={[styles.fontBtnText, { color: fontSize === f ? '#fff' : theme.text }]}>
                    {f === 'small' ? 'K' : f === 'medium' ? 'O' : 'B'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          } />
        </Section>

        <Section title="SOHBET ARKA PLANI">
          <View style={styles.wallpaperGrid}>
            {CHAT_WALLPAPERS.map(w => (
              <TouchableOpacity key={w.id} style={[styles.wallpaperItem, { backgroundColor: darkMode ? w.dark : w.color }, wallpaper === w.id && styles.wallpaperSelected]} onPress={() => changeWallpaper(w.id)}>
                {wallpaper === w.id && <Text style={styles.wallpaperCheck}>✓</Text>}
                <Text style={[styles.wallpaperLabel, { color: darkMode ? '#fff' : '#333' }]}>{w.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Section>

        <Section title="SES & BİLDİRİM">
          <SettingRow icon="🔔" label="Mesaj Sesi" right={
            <Switch value={soundEnabled} onValueChange={toggleSound} trackColor={{ true: theme.accent }} />
          } />
          <SettingRow icon="🎵" label="Bildirim Sesi" right={
            <Text style={[styles.rightText, { color: theme.subText }]}>
              {NOTIFICATION_SOUNDS.find(s => s.id === notificationSound)?.label || '🔔 Varsayılan'}
            </Text>
          } onPress={() => Alert.alert('Bildirim Sesi', '',
            NOTIFICATION_SOUNDS.map(s => ({ text: s.label, onPress: () => changeNotificationSound(s.id) })).concat([{ text: 'İptal', style: 'cancel' }])
          )} />
        </Section>

        <Section title="GİZLİLİK">
          <SettingRow icon="👁️" label="Son Görülmeyi Göster" right={
            <Switch value={lastSeenVisible} onValueChange={toggleLastSeen} trackColor={{ true: theme.accent }} />
          } />
        </Section>

        <Section title="PROFİL">
          <SettingRow icon="👤" label="Profili Düzenle" right={<Text style={{ color: theme.subText }}>›</Text>} onPress={() => navigation.navigate('Profile', { userId })} />
        </Section>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 12, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  content: { padding: 16 },
  section: { marginBottom: 20 },
  sectionTitle: { fontSize: 12, fontWeight: '700', marginBottom: 8, letterSpacing: 0.5 },
  sectionCard: { borderRadius: 14, borderWidth: StyleSheet.hairlineWidth, overflow: 'hidden' },
  row: { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  rowIcon: { fontSize: 20, marginRight: 12 },
  rowLabel: { flex: 1, fontSize: 15, fontWeight: '500' },
  rowRight: { alignItems: 'flex-end' },
  rightText: { fontSize: 14 },
  fontBtns: { flexDirection: 'row', gap: 6 },
  fontBtn: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: '#eee' },
  fontBtnText: { fontWeight: '700', fontSize: 14 },
  wallpaperGrid: { flexDirection: 'row', flexWrap: 'wrap', padding: 10, gap: 8 },
  wallpaperItem: { width: 80, height: 60, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  wallpaperSelected: { borderWidth: 3, borderColor: '#25D366' },
  wallpaperCheck: { fontSize: 18, color: '#25D366', fontWeight: '800' },
  wallpaperLabel: { fontSize: 11, fontWeight: '600', marginTop: 2 },
});
