import React, { useState, useEffect } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  SafeAreaView, TextInput, Alert, Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { formatTime } from '../utils/theme';
import { useApp } from '../context/AppContext';

export default function StatusScreen({ navigation, route }) {
  const { userId } = route.params;
  const { theme } = useApp();
  const [myStatuses, setMyStatuses] = useState([]);
  const [otherStatuses, setOtherStatuses] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    loadProfile();
    loadStatuses();
  }, []);

  async function loadProfile() {
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).single();
    setProfile(data);
  }

  async function loadStatuses() {
    const now = new Date().toISOString();

    const { data: mine } = await supabase.from('statuses').select('*, views:status_views(count)').eq('user_id', userId).gt('expires_at', now).order('created_at', { ascending: false });
    setMyStatuses(mine || []);

    const { data: others } = await supabase.from('statuses').select('*, user:profiles(id,full_name,avatar_url)').neq('user_id', userId).gt('expires_at', now).order('created_at', { ascending: false });

    // Group by user
    const map = {};
    (others || []).forEach(s => {
      if (!map[s.user_id]) map[s.user_id] = { user: s.user, statuses: [] };
      map[s.user_id].statuses.push(s);
    });
    setOtherStatuses(Object.values(map));
  }

  async function createStatus() {
    if (!statusText.trim()) return;
    await supabase.from('statuses').insert({ user_id: userId, content: statusText.trim() });
    setStatusText('');
    setShowCreate(false);
    loadStatuses();
    Alert.alert('✅', 'Durum paylaşıldı! 24 saat sonra silinecek.');
  }

  async function createImageStatus() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;

    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7 });
    if (result.canceled) return;

    const uri = result.assets[0].uri;
    const fileName = `status_${userId}_${Date.now()}.jpg`;
    const response = await fetch(uri);
    const blob = await response.blob();

    const { error } = await supabase.storage.from('chat-images').upload(fileName, blob, { contentType: 'image/jpeg' });
    if (error) return Alert.alert('Hata', 'Fotoğraf yüklenemedi.');

    const { data: urlData } = supabase.storage.from('chat-images').getPublicUrl(fileName);
    await supabase.from('statuses').insert({ user_id: userId, image_url: urlData.publicUrl });
    loadStatuses();
    Alert.alert('✅', 'Fotoğraflı durum paylaşıldı!');
  }

  async function deleteStatus(id) {
    Alert.alert('Durumu Sil', 'Bu durumu silmek istiyor musun?', [
      { text: 'Sil', style: 'destructive', onPress: async () => { await supabase.from('statuses').delete().eq('id', id); loadStatuses(); } },
      { text: 'İptal' },
    ]);
  }

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar style="light" />
      <View style={[styles.header, { backgroundColor: theme.primary }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Durumlar</Text>
      </View>

      <FlatList
        data={[{ type: 'my' }, ...otherStatuses.map(o => ({ type: 'other', ...o }))]}
        keyExtractor={(item, i) => item.user?.id || i.toString()}
        ListHeaderComponent={
          showCreate ? (
            <View style={[styles.createBox, { backgroundColor: theme.surface, borderColor: theme.border }]}>
              <TextInput
                style={[styles.createInput, { color: theme.text, borderColor: theme.border }]}
                placeholder="Ne düşünüyorsun?"
                placeholderTextColor={theme.subText}
                value={statusText}
                onChangeText={setStatusText}
                multiline
                autoFocus
              />
              <View style={styles.createActions}>
                <TouchableOpacity style={styles.createImgBtn} onPress={createImageStatus}>
                  <Text>📷 Fotoğraf</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.createSendBtn, { backgroundColor: theme.accent }]} onPress={createStatus}>
                  <Text style={styles.createSendText}>Paylaş</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : null
        }
        renderItem={({ item }) => {
          if (item.type === 'my') return (
            <View style={[styles.myStatusSection, { borderBottomColor: theme.border }]}>
              <Text style={[styles.sectionLabel, { color: theme.subText }]}>Benim Durumum</Text>
              <TouchableOpacity style={styles.myStatusRow} onPress={() => setShowCreate(true)}>
                <View style={[styles.addBtn, { backgroundColor: theme.accent }]}>
                  <Text style={styles.addBtnText}>+</Text>
                </View>
                <View>
                  <Text style={[styles.myStatusTitle, { color: theme.text }]}>Durum Ekle</Text>
                  <Text style={[styles.myStatusSub, { color: theme.subText }]}>Fotoğraf veya yazı ile</Text>
                </View>
              </TouchableOpacity>
              {myStatuses.map(s => (
                <TouchableOpacity key={s.id} style={styles.myStatusItem} onLongPress={() => deleteStatus(s.id)}>
                  {s.image_url ? <Image source={{ uri: s.image_url }} style={styles.statusThumb} /> : null}
                  <Text style={[styles.myStatusContent, { color: theme.text }]} numberOfLines={2}>{s.content || '📷 Fotoğraf'}</Text>
                  <Text style={[styles.myStatusTime, { color: theme.subText }]}>{formatTime(s.created_at)} · {s.views?.[0]?.count || 0} görüntülenme</Text>
                </TouchableOpacity>
              ))}
            </View>
          );

          return (
            <View style={[styles.otherSection, { borderBottomColor: theme.border }]}>
              {item === otherStatuses[0] && <Text style={[styles.sectionLabel, { color: theme.subText }]}>Son Güncellemeler</Text>}
              <TouchableOpacity style={styles.otherRow} onPress={() => navigation.navigate('StatusView', { statusUserId: item.user?.id, userId })}>
                <View style={[styles.statusRing, { borderColor: theme.accent }]}>
                  <Avatar name={item.user?.full_name || ''} size={48} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.otherName, { color: theme.text }]}>{item.user?.full_name}</Text>
                  <Text style={[styles.otherTime, { color: theme.subText }]}>{formatTime(item.statuses[0]?.created_at)}</Text>
                </View>
                <Text style={[styles.otherCount, { color: theme.accent }]}>{item.statuses.length} durum</Text>
              </TouchableOpacity>
            </View>
          );
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 12, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  createBox: { margin: 12, borderRadius: 14, padding: 14, borderWidth: 1 },
  createInput: { fontSize: 15, minHeight: 80, borderWidth: 1, borderRadius: 10, padding: 10, marginBottom: 10 },
  createActions: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  createImgBtn: { padding: 10 },
  createSendBtn: { borderRadius: 20, paddingVertical: 8, paddingHorizontal: 20 },
  createSendText: { color: '#fff', fontWeight: '700' },
  myStatusSection: { paddingBottom: 8, borderBottomWidth: StyleSheet.hairlineWidth },
  sectionLabel: { fontSize: 12, fontWeight: '700', paddingHorizontal: 16, paddingTop: 12, paddingBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  myStatusRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, gap: 12 },
  addBtn: { width: 50, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center' },
  addBtnText: { color: '#fff', fontSize: 28, fontWeight: '300' },
  myStatusTitle: { fontWeight: '700', fontSize: 15 },
  myStatusSub: { fontSize: 12 },
  myStatusItem: { paddingHorizontal: 16, paddingVertical: 8 },
  statusThumb: { width: 60, height: 60, borderRadius: 8, marginBottom: 6 },
  myStatusContent: { fontSize: 14 },
  myStatusTime: { fontSize: 12, marginTop: 2 },
  otherSection: { borderBottomWidth: StyleSheet.hairlineWidth },
  otherRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  statusRing: { borderWidth: 2.5, borderRadius: 28, padding: 2 },
  otherName: { fontWeight: '700', fontSize: 15 },
  otherTime: { fontSize: 12 },
  otherCount: { fontSize: 12, fontWeight: '600' },
});
