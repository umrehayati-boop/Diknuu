import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, FlatList, TextInput, TouchableOpacity,
  StyleSheet, SafeAreaView, KeyboardAvoidingView, Platform,
  Image, Alert, Modal, AppState, Clipboard, Vibration,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import Avatar from '../components/Avatar';
import { supabase } from '../utils/supabase';
import { sendPushNotification } from '../utils/notifications';
import { formatTime, formatDate } from '../utils/theme';
import { useApp } from '../context/AppContext';

const EMOJIS = ['❤️', '😂', '😮', '😢', '👍', '🔥', '😍', '👎'];

export default function ChatScreen({ navigation, route }) {
  const { userId, partnerId, partnerName, senderName } = route.params;
  const { theme, darkMode, soundEnabled, msgFontSize, wallpaper } = useApp();
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [partnerOnline, setPartnerOnline] = useState(false);
  const [partnerLastSeen, setPartnerLastSeen] = useState(null);
  const [isTyping, setIsTyping] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [selectedMsg, setSelectedMsg] = useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [vanishDuration, setVanishDuration] = useState('off');
  const [showVanish, setShowVanish] = useState(false);
  const flatRef = useRef(null);
  const typingTimeout = useRef(null);

  const chatBg = darkMode ? '#0D1117' : '#ECE5DD';

  useEffect(() => {
    loadMessages();
    markAsRead();
    checkPartnerStatus();
    loadVanishSetting();

    const channel = supabase.channel(`chat_${[userId, partnerId].sort().join('_')}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `receiver_id=eq.${userId}` },
        payload => {
          if (payload.new.sender_id === partnerId) {
            setMessages(prev => [...prev, payload.new]);
            markAsRead();
            scrollToBottom();
          }
        })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' },
        payload => setMessages(prev => prev.map(m => m.id === payload.new.id ? payload.new : m)))
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'typing_status', filter: `sender_id=eq.${partnerId}` },
        payload => {
          if (payload.new.receiver_id === userId) setIsTyping(payload.new.is_typing);
        })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${partnerId}` },
        payload => {
          setPartnerOnline(payload.new.is_online);
          setPartnerLastSeen(payload.new.last_seen);
        })
      .subscribe();

    const appSub = AppState.addEventListener('change', state => { if (state === 'active') markAsRead(); });

    return () => {
      supabase.removeChannel(channel);
      appSub.remove();
      updateTyping(false);
    };
  }, []);

  function scrollToBottom() {
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  }

  async function loadMessages() {
    const { data } = await supabase
      .from('messages')
      .select('*, reply:messages!messages_reply_to_fkey(id,content,sender_id)')
      .or(`and(sender_id.eq.${userId},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${userId})`)
      .order('created_at', { ascending: true });
    setMessages(data || []);
    scrollToBottom();
  }

  async function markAsRead() {
    await supabase.from('messages').update({ is_read: true })
      .eq('sender_id', partnerId).eq('receiver_id', userId).eq('is_read', false);
  }

  async function checkPartnerStatus() {
    const { data } = await supabase.from('profiles').select('is_online,last_seen,last_seen_visible').eq('id', partnerId).single();
    setPartnerOnline(data?.is_online || false);
    setPartnerLastSeen(data?.last_seen_visible ? data?.last_seen : null);
  }

  async function loadVanishSetting() {
    const { data } = await supabase.from('vanish_settings').select('duration').eq('user_id', userId).eq('partner_id', partnerId).single();
    if (data) setVanishDuration(data.duration);
  }

  async function updateTyping(val) {
    try {
      await supabase.from('typing_status').upsert({ sender_id: userId, receiver_id: partnerId, is_typing: val, updated_at: new Date().toISOString() }, { onConflict: 'sender_id,receiver_id' });
    } catch {}
  }

  function handleTextChange(val) {
    setText(val);
    updateTyping(val.length > 0);
    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => updateTyping(false), 2000);
  }

  async function handleSend(imageUrl = null) {
    const content = text.trim();
    if (!content && !imageUrl) return;
    setText('');
    updateTyping(false);

    const { data, error } = await supabase.from('messages').insert({
      sender_id: userId,
      receiver_id: partnerId,
      content: content || null,
      image_url: imageUrl || null,
      is_read: false,
    }).select().single();

    if (error) {
      Alert.alert('Hata', error.message);
      return;
    }

    setReplyTo(null);
    if (data) {
      setMessages(prev => [...prev, data]);
      scrollToBottom();
      await sendPushNotification(partnerId, senderName, imageUrl ? '📷 Fotoğraf' : content);
    }
  }

  async function handleImagePick() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return Alert.alert('İzin gerekli', 'Fotoğraf erişimi için izin ver.');

    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.6 });
    if (result.canceled) return;

    setUploading(true);
    try {
      const uri = result.assets[0].uri;
      const fileName = `chat_${userId}_${Date.now()}.jpg`;

      const response = await fetch(uri);
      const blob = await response.blob();

      const { error } = await supabase.storage.from('chat-images').upload(fileName, blob, { contentType: 'image/jpeg' });
      if (error) throw error;

      const { data: urlData } = supabase.storage.from('chat-images').getPublicUrl(fileName);
      await handleSend(urlData.publicUrl);
    } catch (e) {
      Alert.alert('Hata', 'Fotoğraf gönderilemedi: ' + e.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(msg) {
    Alert.alert('Mesajı Sil', 'Bu mesajı silmek istiyor musun?', [
      {
        text: 'Sil', style: 'destructive', onPress: async () => {
          const { error } = await supabase.from('messages').update({ is_deleted: true, content: null, image_url: null }).eq('id', msg.id);
          if (!error) setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, is_deleted: true, content: null, image_url: null } : m));
        }
      },
      { text: 'İptal' },
    ]);
    setSelectedMsg(null);
  }

  async function handlePin(msg) {
    const newVal = !msg.is_pinned;
    await supabase.from('messages').update({ is_pinned: newVal }).eq('id', msg.id);
    setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, is_pinned: newVal } : m));
    setSelectedMsg(null);
  }

  async function handleReaction(msg, emoji) {
    const reactions = msg.reactions || {};
    const users = reactions[emoji] || [];
    const hasReacted = users.includes(userId);
    const newUsers = hasReacted ? users.filter(u => u !== userId) : [...users, userId];
    const newReactions = { ...reactions, [emoji]: newUsers };
    if (newUsers.length === 0) delete newReactions[emoji];

    await supabase.from('messages').update({ reactions: newReactions }).eq('id', msg.id);
    setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, reactions: newReactions } : m));
    setShowEmojiPicker(false);
    setSelectedMsg(null);
  }

  async function changeVanish(duration) {
    await supabase.from('vanish_settings').upsert({ user_id: userId, partner_id: partnerId, duration }, { onConflict: 'user_id,partner_id' });
    setVanishDuration(duration);
    setShowVanish(false);
  }

  function getSubtitle() {
    if (isTyping) return 'yazıyor...';
    if (partnerOnline) return '🟢 çevrimiçi';
    if (partnerLastSeen) return `son görülme: ${formatTime(partnerLastSeen)}`;
    return '⚫ çevrimdışı';
  }

  const displayMessages = search
    ? messages.filter(m => m.content?.toLowerCase().includes(search.toLowerCase()))
    : messages;

  const pinnedMsgs = messages.filter(m => m.is_pinned && !m.is_deleted);

  function buildItems() {
    const items = [];
    let lastDate = null;
    displayMessages.forEach(m => {
      const d = formatDate(m.created_at);
      if (d !== lastDate) { items.push({ type: 'date', id: 'date_' + m.id, label: d }); lastDate = d; }
      items.push({ type: 'msg', ...m });
    });
    return items;
  }

  function renderItem({ item }) {
    if (item.type === 'date') return (
      <View style={styles.dateSep}>
        <Text style={styles.dateLabel}>{item.label}</Text>
      </View>
    );

    const isMe = item.sender_id === userId;
    const reactions = item.reactions || {};
    const hasReactions = Object.keys(reactions).length > 0;

    return (
      <TouchableOpacity activeOpacity={0.8}
        onLongPress={() => { Vibration.vibrate(30); setSelectedMsg(item); setShowEmojiPicker(false); }}
        style={[styles.bubbleWrap, isMe && styles.myWrap]}
      >
        {item.is_pinned && <Text style={styles.pinnedIcon}>📌</Text>}

        {/* Reply preview */}
        {item.reply && !item.is_deleted && (
          <View style={[styles.replyPreview, { backgroundColor: isMe ? 'rgba(0,0,0,0.1)' : 'rgba(0,0,0,0.06)' }]}>
            <View style={[styles.replyBar, { backgroundColor: '#25D366' }]} />
            <Text style={styles.replyText} numberOfLines={1}>{item.reply.content || '📷 Fotoğraf'}</Text>
          </View>
        )}

        <View style={[styles.bubble, isMe ? [styles.myBubble, { backgroundColor: theme.myBubble }] : [styles.theirBubble, { backgroundColor: theme.theirBubble }]]}>
          {item.is_deleted ? (
            <Text style={styles.deletedText}>🚫 Bu mesaj silindi</Text>
          ) : item.image_url ? (
            <Image source={{ uri: item.image_url }} style={styles.msgImage} resizeMode="cover" />
          ) : (
            <Text style={[styles.msgText, { fontSize: msgFontSize, color: theme.text }]}>{item.content}</Text>
          )}
          <View style={styles.msgMeta}>
            {item.expires_at && <Text style={styles.vanishIcon}>⏱</Text>}
            <Text style={styles.msgTime}>{formatTime(item.created_at)}</Text>
            {isMe && <Text style={[styles.tick, item.is_read && styles.tickRead]}> ✓✓</Text>}
          </View>
        </View>

        {hasReactions && (
          <View style={[styles.reactionsRow, isMe && styles.reactionsRowMe]}>
            {Object.entries(reactions).map(([emoji, users]) => (
              <TouchableOpacity key={emoji} style={styles.reactionBubble} onPress={() => handleReaction(item, emoji)}>
                <Text style={styles.reactionText}>{emoji} {users.length}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </TouchableOpacity>
    );
  }

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar style="light" />

      {/* Header */}
      <View style={[styles.header, { backgroundColor: theme.primary }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Avatar name={partnerName} size={38} />
        <View style={styles.headerInfo}>
          <Text style={styles.headerName}>{partnerName}</Text>
          <Text style={styles.headerSub}>{getSubtitle()}</Text>
        </View>
        <TouchableOpacity style={styles.iconBtn} onPress={() => setShowVanish(true)}>
          <Text>{vanishDuration !== 'off' ? '⏱' : '⋯'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconBtn} onPress={() => setShowSearch(!showSearch)}>
          <Text>🔍</Text>
        </TouchableOpacity>
      </View>

      {/* Pinned messages */}
      {pinnedMsgs.length > 0 && (
        <View style={[styles.pinnedBar, { backgroundColor: theme.surface }]}>
          <Text style={styles.pinnedBarIcon}>📌</Text>
          <Text style={[styles.pinnedBarText, { color: theme.text }]} numberOfLines={1}>
            {pinnedMsgs[pinnedMsgs.length - 1].content || '📷 Fotoğraf'}
          </Text>
        </View>
      )}

      {/* Search */}
      {showSearch && (
        <View style={[styles.searchBar, { backgroundColor: theme.surface }]}>
          <TextInput
            style={[styles.searchInput, { color: theme.text, backgroundColor: theme.inputBg }]}
            placeholder="Mesajlarda ara..."
            placeholderTextColor={theme.subText}
            value={search}
            onChangeText={setSearch}
            autoFocus
          />
          {search ? <TouchableOpacity onPress={() => setSearch('')}><Text style={{ color: theme.subText, marginLeft: 8, fontSize: 16 }}>✕</Text></TouchableOpacity> : null}
        </View>
      )}

      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          ref={flatRef}
          data={buildItems()}
          keyExtractor={item => item.id?.toString()}
          renderItem={renderItem}
          style={[styles.messageList, { backgroundColor: chatBg }]}
          contentContainerStyle={styles.messageContent}
          onContentSizeChange={scrollToBottom}
        />

        {/* Reply bar */}
        {replyTo && (
          <View style={[styles.replyBar2, { backgroundColor: theme.surface, borderTopColor: theme.border }]}>
            <View style={[styles.replyBarLine, { backgroundColor: theme.accent }]} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.replyBarTitle, { color: theme.accent }]}>Yanıtla</Text>
              <Text style={[styles.replyBarText, { color: theme.subText }]} numberOfLines={1}>{replyTo.content || '📷 Fotoğraf'}</Text>
            </View>
            <TouchableOpacity onPress={() => setReplyTo(null)}>
              <Text style={{ fontSize: 18, color: theme.subText }}>✕</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Input */}
        <View style={[styles.inputBar, { backgroundColor: theme.inputBg }]}>
          <TouchableOpacity onPress={handleImagePick} style={[styles.attachBtn, { backgroundColor: theme.surface }]}>
            <Text style={styles.attachIcon}>{uploading ? '⏳' : '📷'}</Text>
          </TouchableOpacity>
          <View style={[styles.inputWrap, { backgroundColor: theme.surface }]}>
            <TextInput
              style={[styles.textInput, { color: theme.text, fontSize: msgFontSize }]}
              value={text}
              onChangeText={handleTextChange}
              placeholder="Mesaj yaz..."
              placeholderTextColor={theme.subText}
              multiline
            />
          </View>
          <TouchableOpacity style={[styles.sendBtn, !text.trim() && styles.sendBtnInactive, { backgroundColor: text.trim() ? theme.accent : '#ccc' }]} onPress={() => handleSend()}>
            <Text style={styles.sendIcon}>{text.trim() ? '➤' : '🎤'}</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      {/* Long press menu */}
      <Modal visible={!!selectedMsg && !showEmojiPicker} transparent animationType="fade" onRequestClose={() => setSelectedMsg(null)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setSelectedMsg(null)}>
          <View style={[styles.actionMenu, { backgroundColor: theme.surface }]}>
            <TouchableOpacity style={styles.actionBtn} onPress={() => setShowEmojiPicker(true)}>
              <Text style={[styles.actionText, { color: theme.text }]}>😊 Tepki Ekle</Text>
            </TouchableOpacity>
            {!selectedMsg?.is_deleted && (
              <TouchableOpacity style={styles.actionBtn} onPress={() => { setReplyTo(selectedMsg); setSelectedMsg(null); }}>
                <Text style={[styles.actionText, { color: theme.text }]}>↩️ Yanıtla</Text>
              </TouchableOpacity>
            )}
            {selectedMsg?.content && !selectedMsg?.is_deleted && (
              <TouchableOpacity style={styles.actionBtn} onPress={() => { Clipboard.setString(selectedMsg.content); setSelectedMsg(null); Alert.alert('✅', 'Kopyalandı!'); }}>
                <Text style={[styles.actionText, { color: theme.text }]}>📋 Kopyala</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity style={styles.actionBtn} onPress={() => handlePin(selectedMsg)}>
              <Text style={[styles.actionText, { color: theme.text }]}>{selectedMsg?.is_pinned ? '📌 Sabitlemeyi Kaldır' : '📌 Sabitle'}</Text>
            </TouchableOpacity>
            {selectedMsg?.sender_id === userId && !selectedMsg?.is_deleted && (
              <TouchableOpacity style={styles.actionBtn} onPress={() => handleDelete(selectedMsg)}>
                <Text style={[styles.actionText, { color: theme.danger }]}>🗑️ Mesajı Sil</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity style={styles.actionBtn} onPress={() => setSelectedMsg(null)}>
              <Text style={[styles.actionText, { color: theme.subText }]}>İptal</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Emoji picker */}
      <Modal visible={showEmojiPicker} transparent animationType="fade" onRequestClose={() => setShowEmojiPicker(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => { setShowEmojiPicker(false); setSelectedMsg(null); }}>
          <View style={[styles.emojiPicker, { backgroundColor: theme.surface }]}>
            {EMOJIS.map(e => (
              <TouchableOpacity key={e} style={styles.emojiBtn} onPress={() => handleReaction(selectedMsg, e)}>
                <Text style={styles.emojiText}>{e}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Vanish mode picker */}
      <Modal visible={showVanish} transparent animationType="slide" onRequestClose={() => setShowVanish(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setShowVanish(false)}>
          <View style={[styles.vanishMenu, { backgroundColor: theme.surface }]}>
            <Text style={[styles.vanishTitle, { color: theme.text }]}>⏱ Süreli Mesajlar</Text>
            {[['off', 'Kapalı'], ['24h', '24 Saat'], ['7d', '7 Gün'], ['90d', '90 Gün']].map(([val, label]) => (
              <TouchableOpacity key={val} style={[styles.vanishOption, vanishDuration === val && { backgroundColor: theme.accent + '22' }]} onPress={() => changeVanish(val)}>
                <Text style={[styles.vanishOptionText, { color: theme.text }]}>{vanishDuration === val ? '✓ ' : ''}{label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  flex: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 8, gap: 8 },
  backBtn: { padding: 6 },
  backText: { color: '#fff', fontSize: 22 },
  headerInfo: { flex: 1 },
  headerName: { color: '#fff', fontWeight: '700', fontSize: 16 },
  headerSub: { color: 'rgba(255,255,255,0.75)', fontSize: 12 },
  iconBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  pinnedBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 8, gap: 8, borderBottomWidth: StyleSheet.hairlineWidth },
  pinnedBarIcon: { fontSize: 14 },
  pinnedBarText: { flex: 1, fontSize: 13 },
  searchBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8 },
  searchInput: { flex: 1, fontSize: 14, padding: 8, borderRadius: 8 },
  messageList: { flex: 1 },
  messageContent: { padding: 10 },
  dateSep: { alignItems: 'center', marginVertical: 10 },
  dateLabel: { backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 4, fontSize: 12, color: '#555', fontWeight: '600' },
  bubbleWrap: { marginBottom: 6, alignItems: 'flex-start' },
  myWrap: { alignItems: 'flex-end' },
  pinnedIcon: { fontSize: 10, marginBottom: 2 },
  replyPreview: { maxWidth: '75%', borderRadius: 8, padding: 6, marginBottom: 3, flexDirection: 'row', overflow: 'hidden' },
  replyBar: { width: 3, borderRadius: 2, marginRight: 6 },
  replyText: { fontSize: 12, color: '#555', flex: 1 },
  bubble: { maxWidth: '75%', padding: 9, paddingHorizontal: 12, borderRadius: 16, elevation: 1 },
  myBubble: { borderBottomRightRadius: 4 },
  theirBubble: { borderBottomLeftRadius: 4 },
  msgText: { lineHeight: 20 },
  deletedText: { fontSize: 14, color: '#aaa', fontStyle: 'italic' },
  msgImage: { width: 200, height: 200, borderRadius: 10 },
  msgMeta: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 3, alignItems: 'center', gap: 2 },
  vanishIcon: { fontSize: 10 },
  msgTime: { fontSize: 11, color: '#888' },
  tick: { fontSize: 11, color: '#aaa' },
  tickRead: { color: '#53BDEB' },
  reactionsRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 3, gap: 4 },
  reactionsRowMe: { justifyContent: 'flex-end' },
  reactionBubble: { backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: 12, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1, borderColor: '#eee', elevation: 1 },
  reactionText: { fontSize: 13 },
  replyBar2: { flexDirection: 'row', alignItems: 'center', padding: 10, borderTopWidth: 1, gap: 8 },
  replyBarLine: { width: 3, height: '100%', borderRadius: 2 },
  replyBarTitle: { fontSize: 12, fontWeight: '700' },
  replyBarText: { fontSize: 13 },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 8, paddingVertical: 6, gap: 8 },
  attachBtn: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', elevation: 1 },
  attachIcon: { fontSize: 20 },
  inputWrap: { flex: 1, borderRadius: 24, paddingHorizontal: 14, paddingVertical: 8, elevation: 1 },
  textInput: { maxHeight: 100 },
  sendBtn: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', elevation: 3 },
  sendBtnInactive: { elevation: 0 },
  sendIcon: { fontSize: 18, color: '#fff' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  actionMenu: { borderRadius: 16, padding: 8, width: 230, elevation: 10 },
  actionBtn: { paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#F0F0F0' },
  actionText: { fontSize: 15, fontWeight: '500' },
  emojiPicker: { borderRadius: 20, padding: 12, flexDirection: 'row', flexWrap: 'wrap', gap: 8, elevation: 10, maxWidth: 300 },
  emojiBtn: { padding: 6 },
  emojiText: { fontSize: 28 },
  vanishMenu: { borderRadius: 20, padding: 16, width: 260, elevation: 10 },
  vanishTitle: { fontSize: 16, fontWeight: '800', marginBottom: 12, textAlign: 'center' },
  vanishOption: { paddingVertical: 14, paddingHorizontal: 12, borderRadius: 10, marginBottom: 4 },
  vanishOptionText: { fontSize: 15, fontWeight: '500' },
});
